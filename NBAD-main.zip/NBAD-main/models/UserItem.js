class UserItem{
  constructor(Item, Rating, madeIt){
    this.Item=Item;
    this.Rating=Rating;
    this.madeIt=madeIt;
}
}
module.exports=UserItem;
